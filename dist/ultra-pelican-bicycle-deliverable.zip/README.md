# Ultra Pelican Bicycle

一只会真蹬车的鹈鹕，骑着一辆电动辅助轮自行车。由 Qoder 中的 AI agent（Qwen4 max）高度自主完成从方案、建模、电控、固件到制造包与操作手册的"泛 coding"开发，并落地为可装配的实物，联动拓竹 H3C 多材料 3D 打印。

## 这个项目为什么存在

- **高度自主的泛 coding**：agent 在 Qoder 里自主完成跨软件 / 固件 / CAD / 电控 / 制造的開發。人（Cindy，按应试教育 11 岁智力设定、极低主观能动性）只按手册做物理操作与采购付款。
- **实物落地**：不是 "pelican riding a bicycle" 的 SVG 梗图，而是真能跑、真能蹬的 3D 打印作品——把这个著名模型基准梗做成实物。
- **拓竹联动**：H3C 九工具头多材料混打——TPU 软胎 + PETG / 碳纤结构 + 软皮塞棉花，软硬同炉。
- **功能达标优先**：不堆花活，先把"骑"做诚实。

气质一句话：要素过多、近乎刻意——Qwen4 max（阿里云千问 token plan）× Qoder（完成度对标 Codex）× 拓竹 H3C × 实物制造，看着像商单但三家一分钱没给，完成度却不念稿；路人不理解但大为震撼。把各家广告里的"究极形态"真做出来。

工程硬约束：**无打样 / DFM 迭代，先验仿真驱动一次成型**——所有验证前置先验分析，保守公差，最终一次性输出完备交付文件。

## 成品是什么

- 约 40cm 的鹈鹕骑自行车，手机 WiFi 遥控（ESP32 自建热点，浏览器大按钮）。
- **单电机驱动后轮，后轮经皮带反过来带动脚踏曲柄，鹈鹕两条腿是从动连杆——车一跑，腿就真蹬**，动作与车速天然同步。
- 助学轮静态稳定（不用动量轮，也不用前轮转向自平衡）。
- 翅膀 / 颈为自锁可摆铰链（G-Flex 共混料）；蹬车腿为低阻自由铰链。
- 鹈鹕本体：碳纤共混骨架承载 + TPU 软空心皮 + 塞棉花。

## 技术栈

| 环节 | 工具 |
| --- | --- |
| 机构建模 | build123d（Python 参数化 CAD） |
| 鹈鹕造型 | Blender |
| 切片 | BambuStudio（拓竹 H3C） |
| 电控 PCB | 嘉立创EDA专业版 + JLCPCB 打样 |
| 主控 / 驱动 | ESP32-C3 SuperMini + DRV8833 + N20 减速电机 + MG90S 舵机 |
| 固件 | ESP32 WiFi AP + 网页遥控 |
| 材料 | TPU / PETG / PET-CF / G-Flex(TPU-PETG) / PEBA + 易拆支撑料 |

## 仓库结构

```
PROJECT_BRIEF.md      项目基线（第一性合同）
PLAN.md               里程碑计划与状态
docs/                 M1 调研 / M2 方案 / 工程完整性自查清单
scripts/              定量校核探针
cad/                  建模源文件与导出（M3 起）
electronics/          电控工程与固件（M4 起）
manufacturing/        切片 / BOM / Cindy 操作手册（M5 起）
```

## 当前状态

M0 基线 ✓ ・ M1 调研 ✓ ・ M2 方案 ✓ ・ M3 建模 ✓ ・ M4 电控 ✓ ・ M5 制造包 ✓ ・ M6 交付自查/打包 ✓。详见 [PLAN.md](PLAN.md)。

## 交付物清单（dist/ 打包）

| 类别 | 内容 |
| --- | --- |
| 建模 | cad/*.py 参数化源 + cad/out/ STL/STEP |
| 电控 | electronics/firmware/ 固件源码+PlatformIO 工程；pinout.md 接线表；pcb_carrier.md 载体板设计 |
| 制造 | manufacturing/bom.csv+md 冻结BOM；slicing.md 切片规范；cindy_manual.md 操作手册 |
| 校核 | scripts/ 运动学/质心/功率预算/M6核对/渲染/打包 |
| 文档 | docs/ 调研/方案/建模规范/完整性清单；PROJECT_BRIEF/PLAN |
| 效果图 | renders/ 整车+各件 QA 图 |

## 制造与复现

面向 Cindy 的完整操作手册（采购 / 打印 / 焊接 / 接线 / 组装 / 调试 / 排障，11 岁可独立执行为硬标准）在 M5 交付。硬件采购 BOM ≤ ¥300（不含打印机与耗材）。

## 交付物

完备工程文件 + 固件源码 + 切片工程 + 完备 BOM + 操作手册，最终统一打包。